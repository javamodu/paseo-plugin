# ORDU-CORE KULLANIM

Tek dosyalik kullanici kilavuzu. Kapsam: test kosma, panoyu acma, CLI komutlari, kanit dosyalari.
Butun komutlar repo kokunden kosulur: `D:\Vibecode\silinecek-task-graph\ordu-core`

## 1. On kosullar

- Node.js 24.x (package.json `engines`: `>=24.0.0 <25`). Dogrulanan surum: v24.18.0.
- Bagimliliklari kur:

```
npm ci
```

Beklenen: exit 0, `found 0 vulnerabilities`. Baska kurulum gerekmez (framework/dis servis YOK).

## 2. Test kosma

```
npm test
```

- Beklenen: exit 0, tum testler PASS (son dogrulama: 186/186, ~36 sn).
- Mutlak test sayisi sart degil (suite buyuyor); sart = exit 0 ve `fail 0`.

## 3. Panoyu acma

```
npm run pano
```

Sunucu yalniz `http://127.0.0.1:<port>` dinler (public bind YOK). Ortam degiskenleri:

| Degisken | Varsayilan | Anlam |
|---|---|---|
| `ORDU_DB` | `data/ordu.sqlite` | Kalici defter (SQLite) dosya yolu; klasor yoksa yaratilir |
| `ORDU_PANO_PORT` | `8787` | Dinleme portu |
| `ORDU_PANO_TOKEN` | rastgele UUID | API tokeni; vermezsen her acilista yenisi uretilir ve konsola basilir |

Acilista konsola su satir basilir (token buradan alinir):

```
pano: http://127.0.0.1:8791  (x-pano-token: <uuid>)
```

Tarayicida `http://127.0.0.1:<port>` ac. Sayfa ilk veri cekiminde token ister (prompt); konsoldaki tokeni yapistir. Token tarayicida localStorage'da saklanir.

Not: Yeni/bos bir defterde rozet `DURDURULDU` gorunebilir — defter fail-closed acilir (`dispatch_paused=1`). Bu hata degil, tasarim; resume icin bkz. bolum 5.

## 4. Panoda ne gorulur

- 5 kart: Dogrulanmis Teslim, Bekleyen Karar, UNKNOWN (rezervasyon), Butce (harcanan/tavan token), Kritik Ihlal.
- 3 bolum: **Kapsuller** (run tablosu: id, planId, state, updatedAt), **Kararlar** (PENDING onaylar: runId, kind, createdAt), **Sistem** (insan mudahalesi sayaci, son 10 olay, ACIL DURDUR butonu).
- Ustte durum rozeti: AKTIF / DURDURULDU. Veri 5 saniyede bir otomatik yenilenir; tum degerler defterden turetilir (uydurma veri yok).

## 5. STOP / RESUME akisi

- **Acil durdur:** Panoda `ACIL DURDUR` butonu → onay promptuna `DURDUR` yaz. CLI'den: `node src/cli.ts stop`.
- **Resume (iki yoldan da ayni kapi):** B01 CLEAR_STOP onay metni zorunlu: `I understand the risk` (birebir, tirnaklar haric).
  - Pano: `/api/resume` govdesi `{"confirm":"I understand the risk"}`.
  - CLI: `node src/cli.ts resume --confirm "I understand the risk"`.
  - Yanlis/eksik metin bilincli olarak RED edilir (exit 1 / HTTP 400) — surtunme kapinin parcasi.

## 6. CLI kullanimi (src/cli.ts — gercek komut listesi)

```
node src/cli.ts status
node src/cli.ts stop [--actor A] [--reason R]
node src/cli.ts resume --confirm "I understand the risk" [--actor A] [--reason R]
node src/cli.ts tick
```

- `status` → JSON: globalStop, pendingOutbox, reserved, unknown, son 5 olay. Exit 0.
- `stop` → global stop latch kurar; `{stopped:true}`. Exit 0.
- `resume` → onay metni olmadan exit 1; dogru metinle `{resumed:true, commandId}`. Exit 0.
- `tick` → tek dispatch gecisi: probe dogrular, B02 yetenek kapisi, outbox + reconcile. Yetenekler kanitlanmamissa `{dispatch:"BLOCKED", reason, note}` ile exit 2 (bugunku durum: Paseo adaptoru wire edilmedigi icin BLOCKED beklenen davranis).
- CLI de `ORDU_DB` (varsayilan `data/ordu.sqlite`) ve `ORDU_PROBE` (varsayilan `evidence/probe-latest.json`) okur.
- Bilinmeyen komut → kullanim satiri + exit 1.

## 7. Kanit dosyalari

- `raporlar/S1.1-KANIT-2026-10-14.md` — S1.1 uctan uca canli akis + F2-A/F2-B kaniti (event zinciri + hash'ler).
- `KANIT-baseline-2026-10-14.md` — baseline olcum + kabul.csv baglantisi.
- `test-out.txt`, `test-out-s11.txt`, `test-out-m16m03.txt` — tam suite ciktilari.
- `evidence/probe-latest.json` — runtime/SDK probe kaniti (tick bunu dogrular).
- Kapi matrisi `kabul.csv`: bu repo disinda, `..\ordu-v3\kabul.csv` (90 satir; F0-A..F7-B kapilari).

## 8. Bilinen sinirlar

- Ucretli/dis API kapali: tum testler hermetik; gercek LLM/Paseo cagrisi YOK.
- Merge/deploy yok: core yalniz defter + dispatch + kabul kapilari; git merge ve yayinlama kapsam disi.
- Paseo adaptoru wire edilmedi: `tick` B02 kapisindan BLOCKED doner (exit 2) — beklenen davranis.
- Pano read-only + stop/resume'dur; plan onayi/karar verme panodan YAPILMAZ.

## 9. Dogrulandi (2026-10-14, Windows, Node v24.18.0)

Asagidaki komutlar bu dokumani yazan oturumda gercekten kosuldu:

| Komut | Sonuc | Exit |
|---|---|---|
| `npm ci` | `found 0 vulnerabilities` | 0 |
| `npm test` | `tests 186 / pass 186 / fail 0` (~36 sn) | 0 |
| `node src/cli.ts status` (temp ORDU_DB) | `{globalStop:true, pendingOutbox:0, reserved:0, unknown:0, lastEvents:[]}` | 0 |
| `node src/cli.ts stop --actor demo --reason dogrulama` | `{stopped:true, actor:"demo"}` | 0 |
| `node src/cli.ts resume --confirm "yanlis metin"` | `resume reddedildi: --confirm "I understand the risk" gerekli` | 1 (beklenen RED) |
| `node src/cli.ts resume --confirm "I understand the risk" --actor demo` | `{resumed:true, commandId:"62041f16-..."}` | 0 |
| `node src/cli.ts tick` | `{dispatch:"BLOCKED", reason:"capability-blocked: worktreeIsolationProven,..."}` | 2 (beklenen kapi) |

Pano kalici-DB dogrulamasi (temp klasor `%TEMP%\ordu-demo-db`, port 8791, token env'siz birakildi):

1. `Start-Process node src/pano-server.ts` (arka plan, ORDU_DB/ORDU_PANO_PORT set) → konsol ciktisina token basildi: `pano: http://127.0.0.1:8791  (x-pano-token: 1b1a0b7e-3d20-4067-97df-f297e706602d)` — token basilmasi dogrulandi.
2. `Invoke-WebRequest http://127.0.0.1:8791/healthz` → 200, govde `ok`.
3. `Invoke-WebRequest http://127.0.0.1:8791/` → 200, `content-type: text/html`, 6215 byte HTML.
4. `/api/status` tokensiz → 403; dogru tokenle → 200 JSON (globalStop:true, bos run listesi).
5. Kalici dosya yaratildi: `ordu-demo-db\ordu.sqlite` (+shm/wal) — kalici DB dogrulandi.
6. Dogrulama sonrasi surec `Stop-Process` ile olduruldu, temp klasor temizlendi; acik sunucu birakilmadi.
